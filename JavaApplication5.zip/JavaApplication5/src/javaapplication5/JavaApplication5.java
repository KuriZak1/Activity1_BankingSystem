/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication5;

import java.util.Arrays;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Jake Marson Nable
 */
public class JavaApplication5 {
    
    
    
    /**
     * 
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        int [] balance = {};
        int loop = 1;
        do {
            System.out.println("Menu:\n [1] DEPOSIT \n [2] WITHDRAW \n [3] CHECK BALANCE\n [4] EXIT");
            int menu = scan.nextInt();
        
            switch(menu){
                case 1:
                    int amount = 0;
                    
                   
                    
                    System.out.println("Please enter deposit amount: ");
                    int elementToInsert = scan.nextInt();
                    
                    int[] newArray = Arrays.copyOf(balance, balance.length + 1 );
                    newArray[newArray.length - 1] = elementToInsert;
                    
                    System.out.println("");
                    
                    System.out.println("Would you like to have another transaction?\n [1] Yes.\n [2] No.\n");
                    int userChoice = scan.nextInt();

                    if(userChoice == 1){
                        System.out.println("Ok, another transaction!\n");
                    }else{
                        System.out.println("Ok, have a nice day.");
                        loop = loop + 1;
                    }
                    
                    break;

                case 2:
                  
                    break;
                case 3:
                    
                    System.out.println("\nYour balance are: ");
                    printArray(balance);
            
                    scan.close();
                    break;

                case 4:
                    System.out.println("Ok thank you!");
                    loop = loop + 1;
                    break;
            }
        }while(loop == 1);       
    }
        
        public static void printArray(int balance[]){
        for (int num : balance){
            System.out.println(num + "");
        }
   }

    
}
